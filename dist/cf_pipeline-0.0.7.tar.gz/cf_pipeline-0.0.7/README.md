# CF Pipeline

A command-line interface tool for automating Codeforces competitive programming workflows.

![Version](https://img.shields.io/badge/version-0.0.7-blue)
![Status](https://img.shields.io/badge/status-alpha-orange)

## Overview

CF Pipeline is a CLI application that streamlines interaction with the Codeforces competitive programming platform. Built with a "plumbing and porcelain" architecture (inspired by Git), it provides a set of composable commands for automating common Codeforces tasks.

## Features

- **Problem retrieval**: Download contest problems directly to your local environment
- **Solution testing**: Test your solutions against sample test cases before submission
- **Workflow automation**: Combine commands to create custom workflows
- **Framework extensibility**: Build your own commands on top of the core framework

## Installation

from github:

 - fork and pull repository
 - navigate to project in terminal
 - from the top level of project, run

```bash
pip install -e .
pip install -r requirements.txt
```

or get it straight from pypi with

```bash
pip install cf-pipeline
```

## Usage

Basic commands:

```bash
# Get a specific problem
cf-getproblem <contest-id> <problem-index>

# Test your solution against problem test cases
cf-testproblem <solution-file> <contest-id> <problem-index>

# plus many more.
```

for a complete list of commands, see [here](https://github.com/lifeModder19135/cf-pipeline/blob/dev-master/ABOUT_THE_APPS.md)

## Architecture

CF Pipeline follows a modular approach:

- **Core modules**: Problem representation, contest data, and configuration management
- **Commands**: Single-purpose tools that can be combined into workflows
- **API utilities**: Tools for interacting with the Codeforces API

## Why Use CF Pipeline?

- **Save time**: Automate repetitive tasks in the competitive programming workflow
- **Focus on coding**: Reduce time spent on administrative tasks
- **Integration**: Use from your terminal without switching to the browser
- **Customization**: Build and extend with your own commands and workflows

## Development Status

This project is in early alpha development (version 0.0.5 "AlmostAlpha"). Many planned features are still in progress.

## Contributing

Contributions are welcome! See our contribution guidelines for details.

## License

See the [LICENSE](RESOURCES/LICENSE) file for details.